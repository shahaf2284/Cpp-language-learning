/* Assignment: 1 
Author: shahaf zohar ID: 205978000
Author: shaked basa, ID: 206310781 
*/ 

#ifndef MENU_HPP
#define MENU_HPP

class Menu
{
public:
    Menu();                 // Print the main Menu
    void mainMenu();
    void twoDigitsMenu(); 
    void fractionMenu();
    void stringMenu();
    
    ~Menu();
};

#endif // MENU_HPP
