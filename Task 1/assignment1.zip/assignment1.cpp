/* Assignment: 1 
Author: shahaf zohar ID: 205978000
Author: shaked basa, ID: 206310781 
*/ 

#include <iostream>
#include "Menu.h"

using namespace std;

int main()
{ 
    Menu menu;
    menu.mainMenu();
    return 0;
}