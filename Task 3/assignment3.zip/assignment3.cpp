/* Assignment: 3  
Author1: shahaf zohar, 
ID: 205978000 
Author2: shaked basa,  
ID: 206310781
 */ 
 
#include "School.h" 
#include <iostream> 

using namespace std;

int main()
{
    School SCHOOL = School::Creat_school();
    SCHOOL.menu();

	return 0;
}
